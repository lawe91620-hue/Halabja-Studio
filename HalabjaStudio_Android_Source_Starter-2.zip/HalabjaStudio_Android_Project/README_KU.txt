HALABJA STUDIO — corrected Android starter

ئەم ZIP ـە لە root ـی GitHub repository باربکە بە ناوی HalabjaStudio_Android_Source_Starter-2.zip.

- MainActivity بە ComponentActivity چاککراوە.
- Java و Kotlin target بۆ 17 ڕێکخراون.
- هێنانی ڤیدیۆ، پێشبینین و exportی کلیپی بڕاو هەیە.
- دوگمەی split بە دروستی ناونراوە و تەنها نیوەی یەکەم export دەکات.

ئەمە APK نییە و Gradle build لێرە نەکراوە. Multi-track، transitions، captions و تایبەتمەندییە پێشکەوتووەکانی CapCut هێشتا تێدا نییە.
