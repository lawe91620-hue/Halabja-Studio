HALABJA STUDIO — بنەمای ئەپی Android

ئەمە سەرچاوەی ئەپی Android ـە، نەک APK ـی ئامادە.
تایبەتمەندییەکانی ئەم قۆناغە:
- هێنانی ڤیدیۆ بە Android Photo Picker
- پێشبینینی ڤیدیۆ
- دیاریکردنی کاتی دەستپێک و کۆتایی بە چرکە
- دەرکردنی کلیپی بڕاو بە Media3 Transformer

تێبینی گرنگ:
- دوگمەی Split لەم وەشانەدا نیوەی یەکەم دەر دەکات؛ بۆ نیوەی دووەم دوای تەواوبوونی export، کاتی start/end بگۆڕە و جارێکی تر export بکە.
- ئەم بنەمایە هێشتا تایبەتمەندییەکانی multitrack، transition، keyframe، captions و AI audio separation نییە.
- APK لەم چاتەدا کۆمپایل و تاقی نەکراوەتەوە.

دروستکردنی APK بە مۆبایل:
1) ZIP ـەکە لە GitHub repo ـێکی نوێدا upload بکە (پێویستە هەموو فایلەکان لە root بن).
2) لە repo ـەکە بچۆ بۆ Actions.
3) Build Halabja Studio APK هەڵبژێرە و Run workflow بکە.
4) کاتێک تەواو بوو، لە Artifacts فایلەکەی HalabjaStudio-debug-apk دابگرە.
5) APK ـەکە دابگرە و لە مۆبایل دایبمەزرێنە.

ئەگەر GitHub هەژمارت نییە، پێویستە یەکەم جار هەژمارێکی خۆڕایی دروست بکەیت.
