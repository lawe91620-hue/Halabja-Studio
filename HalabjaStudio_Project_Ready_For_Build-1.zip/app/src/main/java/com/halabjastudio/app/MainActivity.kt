package com.halabjastudio.app

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var selectedUri: Uri? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private var transformer: Transformer? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(0xFF10131B.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFF3F5FA.toInt())
            setPadding(0, 8, 0, 8)
        }
        val title = label("HALABJA STUDIO", 24f).apply { gravity = Gravity.CENTER }
        val subtitle = label("Mobile video editor • First working build", 13f).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFFADB7C8.toInt())
        }
        playerView = PlayerView(this).apply {
            useController = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            ).apply { topMargin = 14; bottomMargin = 14 }
        }
        val importButton = Button(this).apply {
            text = "Import video"
            setOnClickListener { pickVideo.launch("video/*") }
        }
        val trimTitle = label("TRIM RANGE (seconds)")
        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startInput = EditText(this).apply {
            hint = "Start e.g. 0"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("0")
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA4B5.toInt())
        }
        endInput = EditText(this).apply {
            hint = "End e.g. 10"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA4B5.toInt())
        }
        fields.addView(startInput, LinearLayout.LayoutParams(0, 56, 1f).apply { rightMargin = 8 })
        fields.addView(endInput, LinearLayout.LayoutParams(0, 56, 1f))
        val exportButton = Button(this).apply {
            text = "Export trimmed video"
            setOnClickListener { exportTrimmed() }
        }
        val splitButton = Button(this).apply {
            text = "Export first half"
            setOnClickListener { splitIntoTwo() }
        }
        status = label("Choose a video to begin.", 13f).apply {
            setTextColor(0xFFB9C4D5.toInt())
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(playerView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root.addView(importButton)
        root.addView(trimTitle)
        root.addView(fields)
        root.addView(exportButton)
        root.addView(splitButton)
        root.addView(status)
        setContentView(root)
    }

    private fun loadVideo(uri: Uri) {
        selectedUri = uri
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = false
        }
        status.text = "Video loaded. Preview it, then set start/end seconds."
    }

    private fun readRange(): Pair<Long, Long>? {
        val start = startInput.text.toString().toDoubleOrNull()
        val end = endInput.text.toString().toDoubleOrNull()
        if (start == null || end == null || start < 0 || end <= start) {
            Toast.makeText(this, "Enter a valid start and end time.", Toast.LENGTH_LONG).show()
            return null
        }
        return (start * 1_000_000).toLong() to (end * 1_000_000).toLong()
    }

    private fun exportClip(startUs: Long, endUs: Long, suffix: String) {
        val uri = selectedUri ?: return
        if (endUs <= startUs) {
            Toast.makeText(this, "Clip end must be after clip start.", Toast.LENGTH_LONG).show()
            return
        }
        val outDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val output = File(outDir, "Halabja_${System.currentTimeMillis()}_$suffix.mp4")
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startUs / 1000)
            .setEndPositionMs(endUs / 1000)
            .build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()
        status.text = "Exporting $suffix… please keep the app open."
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                status.text = "Finished: ${output.name}\nSaved in app Movies folder."
                Toast.makeText(this@MainActivity, "Export finished.", Toast.LENGTH_LONG).show()
            }
            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                status.text = "Export failed: ${exportException.message ?: "unknown error"}"
            }
        }
        transformer = Transformer.Builder(this).addListener(listener).build()
        transformer?.start(EditedMediaItem.Builder(item).build(), output.absolutePath)
    }

    private fun exportTrimmed() {
        val range = readRange() ?: return
        exportClip(range.first, range.second, "trim")
    }

    private fun splitIntoTwo() {
        val range = readRange() ?: return
        val middle = range.first + (range.second - range.first) / 2
        // Export first half, then the second half after the first export completes is
        // intentionally left as two explicit actions in this starter to avoid parallel
        // Transformer jobs on lower-end Android phones.
        exportClip(range.first, middle, "part1")
        Toast.makeText(this, "First half exporting. After it finishes, set the start/end to the second half and export again.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        transformer?.cancel()
        player?.release()
        player = null
        super.onDestroy()
    }
}
