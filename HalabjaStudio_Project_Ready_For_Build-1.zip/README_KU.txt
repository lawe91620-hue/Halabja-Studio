HALABJA STUDIO — Android project

ئەمە سەرچاوەی پرۆژەی Android ـە، APK نییە.
ئەم وەشانە:
- ڤیدیۆ هەڵدەبژێرێت و پێشبینینی دەکات.
- کاتی دەستپێک و کۆتایی دیاری دەکات.
- کلیپی بڕاو وەک MP4 هەناردە دەکات.
- بنەمای ComponentActivity چاککراوە بۆ registerForActivityResult.

تێبینی:
- دوگمەی Export first half تەنها نیوەی یەکەم هەناردە دەکات.
- فایلە هەناردەکراوەکان لە فۆڵدەری تایبەتی ئەپی Movies دادەنرێن.
- ئەم وەشانە هێشتا CapCut هاوشێوەی تەواو نییە؛ multi-track، transition، captions و effect هێشتا دروست نەکراون.
- APK هێشتا Build و تاقی نەکراوەتەوە.

بۆ Build:
پڕۆژەکە دەبێت لە ژینگەیەکی Android/Gradle build بکرێت.
