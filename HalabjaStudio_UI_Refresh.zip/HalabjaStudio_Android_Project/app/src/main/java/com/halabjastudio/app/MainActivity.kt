package com.halabjastudio.app

import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ScrollView
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var selectedUri: Uri? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private var transformer: Transformer? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }

    private fun makeLabel(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false
    ) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun styleActionButton(button: Button, primary: Boolean) {
        button.isAllCaps = false
        button.textSize = 15f
        button.typeface = Typeface.DEFAULT_BOLD
        button.setTextColor(if (primary) Color.WHITE else Color.rgb(220, 225, 240))
        button.background = rounded(
            if (primary) Color.rgb(112, 86, 255) else Color.rgb(34, 39, 55),
            16,
            if (primary) Color.TRANSPARENT else Color.rgb(58, 65, 86)
        )
        button.minHeight = dp(54)
        button.stateListAnimator = null
        button.setPadding(dp(16), dp(8), dp(16), dp(8))
    }

    private fun buildScreen() {
        val bg = Color.rgb(12, 15, 25)
        val panel = Color.rgb(23, 28, 43)
        val white = Color.rgb(245, 247, 255)
        val muted = Color.rgb(157, 167, 190)
        val accent = Color.rgb(112, 86, 255)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(bg)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brandColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        brandColumn.addView(makeLabel("HALABJA", 25f, white, true))
        brandColumn.addView(makeLabel("STUDIO  •  VIDEO EDITOR", 10f, muted, true))
        val version = makeLabel("BETA", 11f, Color.rgb(194, 184, 255), true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(13), dp(7), dp(13), dp(7))
            background = rounded(Color.rgb(43, 37, 78), 30)
        }
        top.addView(brandColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(version)
        root.addView(top)

        val welcome = makeLabel("Create something beautiful.", 19f, white, true).apply {
            setPadding(0, dp(24), 0, dp(4))
        }
        root.addView(welcome)
        root.addView(makeLabel("Import a video and start editing", 13f, muted))

        val previewCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(panel, 22, Color.rgb(42, 49, 69))
        }
        playerView = PlayerView(this).apply {
            useController = true
            setBackgroundColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(270)
            )
        }
        previewCard.addView(playerView)
        val previewCaption = makeLabel("VIDEO PREVIEW", 10f, muted, true).apply {
            setPadding(dp(5), dp(10), dp(5), dp(3))
        }
        previewCard.addView(previewCaption)
        val previewParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(18) }
        root.addView(previewCard, previewParams)

        val importButton = Button(this).apply {
            text = "＋   Import video"
            styleActionButton(this, true)
            setOnClickListener { pickVideo.launch("video/*") }
        }
        root.addView(importButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
        ).apply { topMargin = dp(14) })

        val editCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(panel, 20, Color.rgb(42, 49, 69))
        }
        val trimHeading = makeLabel("Trim your video", 18f, white, true)
        editCard.addView(trimHeading)
        editCard.addView(makeLabel("Choose the part you want to keep", 12f, muted).apply {
            setPadding(0, dp(4), 0, dp(14))
        })

        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun timeField(hintText: String, initial: String): EditText =
            EditText(this).apply {
                hint = hintText
                setText(initial)
                textSize = 15f
                setTextColor(white)
                setHintTextColor(muted)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                singleLine = true
                gravity = Gravity.CENTER
                background = rounded(Color.rgb(14, 18, 30), 12, Color.rgb(57, 65, 88))
                setPadding(dp(8), 0, dp(8), 0)
            }

        startInput = timeField("Start (sec)", "0")
        endInput = timeField("End (sec)", "")
        fields.addView(startInput, LinearLayout.LayoutParams(0, dp(52), 1f))
        fields.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        fields.addView(endInput, LinearLayout.LayoutParams(0, dp(52), 1f))
        editCard.addView(fields)

        val exportButton = Button(this).apply {
            text = "Export trimmed video"
            styleActionButton(this, true)
            setOnClickListener { exportTrimmed() }
        }
        editCard.addView(exportButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(54)
        ).apply { topMargin = dp(14) })

        val splitButton = Button(this).apply {
            text = "Export first half"
            styleActionButton(this, false)
            setOnClickListener { splitIntoTwo() }
        }
        editCard.addView(splitButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(9) })

        root.addView(editCard, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })

        status = makeLabel("Ready when you are — import a video to begin.", 12f, muted).apply {
            setPadding(dp(4), dp(16), dp(4), dp(8))
        }
        root.addView(status)
        setContentView(scroll)
    }

    private fun loadVideo(uri: Uri) {
        selectedUri = uri
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = false
        }
        status.text = "Video loaded. Preview it, then set start/end seconds."
    }

    private fun readRange(): Pair<Long, Long>? {
        val start = startInput.text.toString().toDoubleOrNull()
        val end = endInput.text.toString().toDoubleOrNull()
        if (start == null || end == null || start < 0 || end <= start) {
            Toast.makeText(this, "Enter a valid start and end time.", Toast.LENGTH_LONG).show()
            return null
        }
        return (start * 1_000_000).toLong() to (end * 1_000_000).toLong()
    }

    private fun exportClip(startUs: Long, endUs: Long, suffix: String) {
        val uri = selectedUri ?: return
        if (endUs <= startUs) {
            Toast.makeText(this, "Clip end must be after clip start.", Toast.LENGTH_LONG).show()
            return
        }
        val outDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        val output = File(outDir, "Halabja_${System.currentTimeMillis()}_$suffix.mp4")
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startUs / 1000)
            .setEndPositionMs(endUs / 1000)
            .build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()
        status.text = "Exporting $suffix… please keep the app open."
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                status.text = "Finished: ${output.name}\nSaved in app Movies folder."
                Toast.makeText(this@MainActivity, "Export finished.", Toast.LENGTH_LONG).show()
            }
            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                status.text = "Export failed: ${exportException.message ?: "unknown error"}"
            }
        }
        transformer = Transformer.Builder(this).addListener(listener).build()
        transformer?.start(EditedMediaItem.Builder(item).build(), output.absolutePath)
    }

    private fun exportTrimmed() {
        val range = readRange() ?: return
        exportClip(range.first, range.second, "trim")
    }

    private fun splitIntoTwo() {
        val range = readRange() ?: return
        val middle = range.first + (range.second - range.first) / 2
        // Export first half, then the second half after the first export completes is
        // intentionally left as two explicit actions in this starter to avoid parallel
        // Transformer jobs on lower-end Android phones.
        exportClip(range.first, middle, "part1")
        Toast.makeText(this, "First half exporting. After it finishes, set the start/end to the second half and export again.", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        transformer?.cancel()
        player?.release()
        player = null
        super.onDestroy()
    }
}
